<div class="partner-area bg pb-10 pt-10">
    <div class="container">
        <div class="partner-wrapper partner-slider owl-carousel owl-theme">
            <img src="assets/img/partner/castor.png" style="width: 80px;" alt="thumb">
            <img src="assets/img/partner/hyper.png" style="width: 80px;" alt="thumb">
            <img src="assets/img/partner/ovk.png" style="width: 80px;" alt="thumb">
            <img src="assets/img/partner/millenium-bg.png" alt="thumb">
            <img src="assets/img/partner/logofisco.png" alt="thumb">
            <img src="assets/img/partner/mamb.jpg" style="width: 80px;" alt="thumb">
        </div>
    </div>
</div>
