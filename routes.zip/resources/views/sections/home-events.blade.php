<div class="event-area bg py-120">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 mx-auto">
                <div class="site-heading text-center">
                    <span class="site-title-tagline"><i class="far fa-calendar-clock"></i> Evénements</span>
                    <h2 class="site-title">Nos <span>Evénements</span> à venir</h2>
                    <p>Soyez le premier informé de nos événements et profitez-en avant tout le monde.</p>
                </div>
            </div>
        </div>
        <div class="event-slider owl-carousel owl-theme">
            <div class="event-item">
                <div class="event-location">
                    <span><i class="far fa-map-marker-alt"></i> 25/B Milford Road, New York</span>
                </div>
                <div class="event-img">
                    <img src="assets/img/event/01.jpg" alt="">
                </div>
                <div class="event-info">
                    <div class="event-meta">
                        <span class="event-date"><i class="far fa-calendar-alt"></i>16 June, 2024</span>
                        <span class="event-time"><i class="far fa-clock"></i>10.00AM - 04.00PM</span>
                    </div>
                    <h4 class="event-title"><a href="event-single.html">High School Program 2024</a></h4>
                    <p>There are many variations of passages the majority have some injected humour.</p>
                    <div class="event-btn">
                        <a href="event-single.html" class="theme-btn">Join Event<i
                                class="fas fa-arrow-right-long"></i></a>
                    </div>
                </div>
            </div>
            <div class="event-item">
                <div class="event-location">
                    <span><i class="far fa-map-marker-alt"></i> 25/B Milford Road, New York</span>
                </div>
                <div class="event-img">
                    <img src="assets/img/event/02.jpg" alt="">
                </div>
                <div class="event-info">
                    <div class="event-meta">
                        <span class="event-date"><i class="far fa-calendar-alt"></i>16 June, 2024</span>
                        <span class="event-time"><i class="far fa-clock"></i>10.00AM - 04.00PM</span>
                    </div>
                    <h4 class="event-title"><a href="event-single.html">High School Program 2024</a></h4>
                    <p>There are many variations of passages the majority have some injected humour.</p>
                    <div class="event-btn">
                        <a href="event-single.html" class="theme-btn">Join Event<i
                                class="fas fa-arrow-right-long"></i></a>
                    </div>
                </div>
            </div>
            <div class="event-item">
                <div class="event-location">
                    <span><i class="far fa-map-marker-alt"></i> 25/B Milford Road, New York</span>
                </div>
                <div class="event-img">
                    <img src="assets/img/event/03.jpg" alt="">
                </div>
                <div class="event-info">
                    <div class="event-meta">
                        <span class="event-date"><i class="far fa-calendar-alt"></i>16 June, 2024</span>
                        <span class="event-time"><i class="far fa-clock"></i>10.00AM - 04.00PM</span>
                    </div>
                    <h4 class="event-title"><a href="event-single.html">High School Program 2024</a></h4>
                    <p>There are many variations of passages the majority have some injected humour.</p>
                    <div class="event-btn">
                        <a href="event-single.html" class="theme-btn">Join Event<i
                                class="fas fa-arrow-right-long"></i></a>
                    </div>
                </div>
            </div>
            <div class="event-item">
                <div class="event-location">
                    <span><i class="far fa-map-marker-alt"></i> 25/B Milford Road, New York</span>
                </div>
                <div class="event-img">
                    <img src="assets/img/event/04.jpg" alt="">
                </div>
                <div class="event-info">
                    <div class="event-meta">
                        <span class="event-date"><i class="far fa-calendar-alt"></i>16 June, 2024</span>
                        <span class="event-time"><i class="far fa-clock"></i>10.00AM - 04.00PM</span>
                    </div>
                    <h4 class="event-title"><a href="event-single.html">High School Program 2024</a></h4>
                    <p>There are many variations of passages the majority have some injected humour.</p>
                    <div class="event-btn">
                        <a href="event-single.html" class="theme-btn">Join Event<i
                                class="fas fa-arrow-right-long"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
